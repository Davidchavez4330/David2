def gramSchmidt(vector):
  """ Take the Gram-Schmidt of the given inputs.
  
  Short Description

  Args:
    arg1: describe arg1
    arg2: describe arg2
  
  Returns:
    describe what your functions returns
  """
  